package ru.tehkode.permissions;

public interface PermissionsGroupData extends PermissionsData {
}
