PermissionsEx is a powerful permissions plugin for Bukkit powered servers

For instuctions use https://github.com/PEXPlugins/PermissionsEx/wiki