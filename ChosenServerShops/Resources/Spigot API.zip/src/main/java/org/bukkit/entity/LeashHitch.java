package org.bukkit.entity;

/**
 * Represents a Leash Hitch on a fence
 */
public interface LeashHitch extends Hanging {
}
