package org.bukkit.entity;

/**
 * Represents a small {@link Fireball}
 */
public interface SmallFireball extends Fireball {

}
