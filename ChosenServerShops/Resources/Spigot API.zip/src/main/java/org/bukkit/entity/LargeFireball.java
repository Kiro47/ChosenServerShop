package org.bukkit.entity;

/**
 * Represents a large {@link Fireball}
 */
public interface LargeFireball extends Fireball {
}
